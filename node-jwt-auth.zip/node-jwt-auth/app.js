const express = require('express');
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs'); // Untuk enkripsi password
const jwt = require('jsonwebtoken'); // Untuk menghasilkan token JWT
require('dotenv').config();  // Memuat variabel lingkungan dari .env

const app = express();
const path = require('path');
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));  // Gunakan path absolut


// Middleware untuk parsing body
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Koneksi langsung ke MongoDB
mongoose.connect(process.env.MONGO_URI, {
  connectTimeoutMS: 30000, // 30 detik
  socketTimeoutMS: 45000,  // 45 detik
})
  .then(() => console.log('MongoDB connected'))
  .catch((err) => console.log('MongoDB connection error:', err));

// Model MongoDB untuk koleksi pengguna
const User = mongoose.model('User', new mongoose.Schema({
  name: { type: String, required: true },
  email: { type: String, required: true, unique: true },
  password: { type: String, required: true },
}));

// Route untuk halaman utama yang menampilkan data
app.get('/', async (req, res) => {
  try {
    // Ambil data pengguna dari MongoDB
    const users = await User.find();  // Menampilkan semua pengguna
    // Render halaman dengan data pengguna
    res.render('index', { users });
  } catch (err) {
    console.error(err);
    res.status(500).send('Error fetching data');
  }
});

// Route untuk registrasi pengguna baru
app.post('/register', async (req, res) => {
  const { name, email, password } = req.body;
  try {
    // Cek apakah email sudah ada
    const existingUser = await User.findOne({ email });
    if (existingUser) {
      return res.status(400).send('Email already in use');
    }

    // Enkripsi password
    const hashedPassword = await bcrypt.hash(password, 10);

    // Simpan pengguna baru ke MongoDB
    const newUser = new User({
      name,
      email,
      password: hashedPassword,
    });
    await newUser.save();
    res.status(201).send('User registered successfully');
  } catch (err) {
    console.error(err);
    res.status(500).send('Error registering user');
  }
});

// Route untuk login pengguna
// Route untuk login pengguna
app.post('/login', async (req, res) => {
    const { email, password } = req.body;
    try {
      // Cari pengguna berdasarkan email
      const user = await User.findOne({ email });
      if (!user) {
        console.log("User tidak ditemukan:", email);
        return res.status(400).send('Invalid credentials');
      }
  
      // Periksa apakah password yang dimasukkan sesuai dengan yang tersimpan di database
      const isMatch = await bcrypt.compare(password, user.password);
      if (!isMatch) {
        console.log("Password tidak cocok untuk pengguna:", email);
        return res.status(400).send('Invalid credentials');
      }
  
      // Generate JWT Token
      const token = jwt.sign({ userId: user._id }, process.env.JWT_SECRET, { expiresIn: '1h' });
  
      res.status(200).json({ message: 'Login successful', token });
    } catch (err) {
      console.error(err);
      res.status(500).send('Error logging in');
    }
  });
  

// Jalankan server pada port yang ditentukan
const port = process.env.PORT || 5000;
app.listen(port, () => {
  console.log(`Server berjalan di port ${port}`);
});
