const mongoose = require('mongoose');
require('dotenv').config(); // Memuat variabel lingkungan dari file .env

const connectDB = async () => {
  try {
    const uri = `mongodb+srv://${process.env.taufanizl}:${process.env.taufanizl}@cluster0.5ek0x.mongodb.net/${process.env.API}?retryWrites=true&w=majority`;

    console.log('Connecting to MongoDB...');
    await mongoose.connect(uri);  // Hapus opsi useNewUrlParser dan useUnifiedTopology

    console.log('MongoDB connected');
  } catch (error) {
    console.error('Error connecting to MongoDB:', error);
    process.exit(1); // Keluar jika gagal terhubung
  }
};

module.exports = connectDB;
