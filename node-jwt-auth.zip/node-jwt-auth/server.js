const mongoose = require('mongoose');
require('dotenv').config();  // Memuat variabel lingkungan dari file .env


const connectDB = async () => {
  try {
    // Gunakan variabel lingkungan untuk kredensial
    const uri = `mongodb+srv://${process.env.taufanpradnya4ever}:${process.env.taufanpradnya4ever}@cluster0.5ek0x.mongodb.net/${process.env.DB_NAME}?retryWrites=true&w=majority`;

    // Koneksi ke MongoDB
    await mongoose.connect(uri, {
      useNewUrlParser: true,
      useUnifiedTopology: true,
    });

    console.log('MongoDB connected');
  } catch (error) {
    console.error('Error connecting to MongoDB:', error);
    process.exit(1); // Keluar jika gagal terhubung
  }
};

module.exports = connectDB;
